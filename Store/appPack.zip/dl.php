<?php
$var = str_replace('/', ' ', $_GET['a']);
$n = strtok($var, " "); 
$path = '../' . $n;

$url = file_get_contents("repo.txt").$_GET['a'];
$zipFile = $path.'/'.$n.'.zip';

$zip_resource = fopen($zipFile, "w");

$ch_start = curl_init();
curl_setopt($ch_start, CURLOPT_URL, $url);
curl_setopt($ch_start, CURLOPT_FAILONERROR, true);
curl_setopt($ch_start, CURLOPT_HEADER, 0);
curl_setopt($ch_start, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch_start, CURLOPT_AUTOREFERER, true);
curl_setopt($ch_start, CURLOPT_BINARYTRANSFER,true);
curl_setopt($ch_start, CURLOPT_TIMEOUT, 10);
curl_setopt($ch_start, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch_start, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch_start, CURLOPT_FILE, $zip_resource);
$page = curl_exec($ch_start);
if(!$page)
{
 	header('Location: menu.php?e=Download error occurred! PHP couldnt download the ZIP.');
	die();
}
curl_close($ch_start);

$zip = new ZipArchive;
$extractPath = $path;
if($zip->open($zipFile) != "true")
{
	header("Location: menu.php?e=Download error occurred! Unable to open the ZIP file.");
	die();
} 

$zip->extractTo($extractPath);
$zip->close();
unlink($n.'.zip');
header("Location: menu.php?e=App download process complete, no errors returned.");
die();
?>